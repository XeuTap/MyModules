This is simple binary search module
binary searching is working only for sorted lists!!!!