from setuptools import setup
setup(
    name='binsearch',
    version='1.0',
    description='Binary search module',
    author='XeuTap',
    author_email='ctehkas@gmail.com',
    url='',
    py_modules=['binarysearch']
)