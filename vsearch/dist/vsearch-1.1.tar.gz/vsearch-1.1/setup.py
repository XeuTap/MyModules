from setuptools import setup

setup(
    name='vsearch',
    version='1.1',
    author='XeuTap',
    py_modules=['vsearch'])
